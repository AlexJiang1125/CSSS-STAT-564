# Shiny app demo for Bayesian inference

This Shiny app is a demo of Bayesian inference for normal mean (known variance).

- Mirror 1: https://nanx.app/conjugate-normal-umkv/
- Mirror 2: https://nanx.shinyapps.io/conjugate-normal-umkv/

For details, please check out [the vignette](https://stephens999.github.io/fiveMinuteStats/shiny_normal_example.html) and [fiveMinuteStats](https://stephens999.github.io/fiveMinuteStats/).
